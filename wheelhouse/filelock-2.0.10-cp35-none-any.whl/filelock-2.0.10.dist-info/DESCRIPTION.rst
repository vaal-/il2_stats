=======

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>

Download-URL: https://github.com/benediktschmitt/py-filelock/archive/master.zip
Description: Py-FileLock
        ===========
        
        This package contains a single module, which implements a platform independent
        file lock in Python.
        
        The lock includes a lock counter and is thread safe. This means, when locking
        the same lock object twice, it will not block.
        
        .. code-block:: python
        
        	import filelock
        
        	lock = filelock.FileLock("my_lock_file")
        
        	with lock:
        		pass
        
        	try:
        		with lock.acquire(timeout = 10):
        			pass
        	except filelock.Timeout:
        		pass
        
        
        What this *filelock* is not
        ---------------------------
        
        A *filelock* provides a synchronisation mechanism between different instances
        of your application, similar to a thread lock. It can be used to *signalize*
        that files, directories or other resources are currently used or manipulated
        (Think of a sync.lock file). Only the existence of the lockfile is watched for
        this purpose. The file itself can not be written and is always empty.
        
        Perhaps you are looking for something like
        
        *	https://pypi.python.org/pypi/pid/2.1.1
        * https://docs.python.org/3.6/library/msvcrt.html#msvcrt.locking
        * or https://docs.python.org/3/library/fcntl.html#fcntl.flock
        
        
        Documentation
        -------------
        
        The full documentation is available on
        `readthedocs.org <https://filelock.readthedocs.io/>`_.
        
        
        Contributions
        -------------
        
        Contributions are always welcome. Never hesitate to open a new issue.
        
        
        License
        -------
        
        This package is `public domain <LICENSE.rst>`_.
        
Platform: UNKNOWN
Classifier: License :: Public Domain
Classifier: Development Status :: 5 - Production/Stable
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python :: 3
Classifier: Intended Audience :: Developers
Classifier: Topic :: System
Classifier: Topic :: Internet
Classifier: Topic :: Software Development :: Libraries
