tzlocal
=======

This Python module returns a `tzinfo` object with the local timezone information under Unix and Win-32.
It requires `pytz`, and returns `pytz` `tzinfo` objects.

This module attempts to fix a glaring hole in `pytz`, that there is no way to
get the local timezone information, unless you know the zoneinfo name, and
under several Linux distros that's hard or impossible to figure out.

Also, with Windows different timezone system using pytz isn't of much use
unless you separately configure the zoneinfo timezone name.

With `tzlocal` you only need to call `get_localzone()` and you will get a
`tzinfo` object with the local time zone info. On some Unices you will still
not get to know what the timezone name is, but you don't need that when you
have the tzinfo file. However, if the timezone name is readily available it
will be used.


Supported systems
-----------------

These are the systems that are in theory supported:

 * Windows 2000 and later

 * Any unix-like system with a /etc/localtime or /usr/local/etc/localtime

If you have one of the above systems and it does not work, it's a bug.
Please report it.


Usage
-----

Load the local timezone:

    >>> from tzlocal import get_localzone
    >>> tz = get_localzone()
    >>> tz
    <DstTzInfo 'Europe/Warsaw' WMT+1:24:00 STD>

Create a local datetime:

    >>> from datetime import datetime
    >>> dt = tz.localize(datetime(2015, 4, 10, 7, 22))
    >>> dt
    datetime.datetime(2015, 4, 10, 7, 22, tzinfo=<DstTzInfo 'Europe/Warsaw' CEST+2:00:00 DST>)

Lookup another timezone with `pytz`:

    >>> import pytz
    >>> eastern = pytz.timezone('US/Eastern')

Convert the datetime:

    >>> dt.astimezone(eastern)
    datetime.datetime(2015, 4, 10, 1, 22, tzinfo=<DstTzInfo 'US/Eastern' EDT-1 day, 20:00:00 DST>)


Maintainer
----------

* Lennart Regebro, regebro@gmail.com

Contributors
------------

* Marc Van Olmen
* Benjamen Meyer
* Manuel Ebert
* Xiaokun Zhu
* Cameris
* Edward Betts
* McK KIM
* Cris Ewing
* Ayala Shachar
* Lev Maximov
* Jakub Wilk
* John Quarles

(Sorry if I forgot someone)

License
-------

* CC0 1.0 Universal  http://creativecommons.org/publicdomain/zero/1.0/


Changes
=======

1.4 (2017-04-18)
----------------

- I use MIT on my other projects, so relicensing.


1.4b1 (2017-04-14)
------------------

- Dropping support for Python versions nobody uses (2.5, 3.1, 3.2), adding 3.6
  Python 3.1 and 3.2 still works, 2.5 has been broken for some time.

- Ayalash's OS X fix didn't work on Python 2.7, fixed that.


1.3.2 (2017-04-12)
------------------

- Ensure closing of subprocess on OS X (ayalash)

- Removed unused imports (jwilk)

- Closes stdout and stderr to get rid of ResourceWarnings (johnwquarles)

- Updated Windows timezones (axil)


1.3 (2016-10-15)
----------------

- #34: Added support for /var/db/zoneinfo


1.2.2 (2016-03-02)
------------------

- #30: Fixed a bug on OS X.


1.2.1 (2016-02-28)
------------------

- Tests failed if TZ was set in the environment. (EdwardBetts)

- Replaces os.popen() with subprocess.Popen() for OS X to
  handle when systemsetup doesn't exist. (mckabi, cewing)


1.2 (2015-06-14)
----------------

- Systemd stores no time zone name, forcing us to look at the name of the file
  that localtime symlinks to. (cameris)


1.1.2 (2014-10-18)
------------------

- Timezones that has 3 items did not work on Mac OS X.
  (Marc Van Olmen)

- Now doesn't fail if the TZ environment variable isn't an Olsen time zone.

- Some timezones on Windows can apparently be empty (perhaps the are deleted).
  Now these are ignored.
  (Xiaokun Zhu)


1.1.1 (2014-01-29)
------------------

- I forgot to add Etc/UTC as an alias for Etc/GMT.


1.1 (2014-01-28)
----------------

- Adding better support for OS X.

- Added support to map from tzdata/Olsen names to Windows names.
  (Thanks to Benjamen Meyer).


1.0 (2013-05-29)
----------------

- Fixed some more cases where spaces needs replacing with underscores.

- Better handling of misconfigured /etc/timezone.

- Better error message on Windows if we can't find a timezone at all.


0.3 (2012-09-13)
----------------

- Windows 7 support.

- Python 2.5 supported; because it only needed a __future__ import.

- Python 3.3 tested, it worked.

- Got rid of relative imports, because I don't actually like them,
  so I don't know why I used them in the first place.

- For each Windows zone, use the default zoneinfo zone, not the last one.


0.2 (2012-09-12)
----------------

- Python 3 support.


0.1 (2012-09-11)
----------------

- Initial release.


